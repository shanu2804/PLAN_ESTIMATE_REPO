package plan.estimate.planestimate.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class Genric<U> {
	
@Column(name = "created_date")
@CreatedDate
public Date createdts;
@Column(name = "modified_date")
@LastModifiedDate
public Date modifiedts;


public Date getCreatedts() {
	return createdts;
}
public void setCreatedts(Date createdts) {
	this.createdts = createdts;
}
public Date getModifiedts() {
	return modifiedts;
}
public void setModifiedts(Date modifiedts) {
	this.modifiedts = modifiedts;
}

}
