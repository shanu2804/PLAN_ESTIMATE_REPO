package plan.estimate.planestimate.service;

import java.util.Arrays;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Role;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import plan.estimate.planestimate.model.User;
import plan.estimate.planestimate.repository.RoleRepository;
import plan.estimate.planestimate.repository.UserRepository;



@Service("userService")
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	@Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    

	@Override
	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public void saveUser(User user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setActive(1);
        String userRole = new String("ADMIN");
		/* user.setRoles(new HashSet<Role>(Arrays.asList(userRole))); */
        user.setRoles(userRole);
        userRepository.save(user);
	}
	
	


}
