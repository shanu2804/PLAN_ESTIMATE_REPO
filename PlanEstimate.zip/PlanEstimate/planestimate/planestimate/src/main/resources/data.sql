INSERT INTO planestimate.role VALUES (1,'ADMIN');

INSERT INTO planestimate.user values (1,1,'test@gmail.com','Test','Test','admin');

INSERT INTO planestimate.userrole VALUES (1,1);

--insert into track (created_date,modified_date,track_description,track_name) values (sysdate(),sysdate(),'Commerce Issue','COM');
