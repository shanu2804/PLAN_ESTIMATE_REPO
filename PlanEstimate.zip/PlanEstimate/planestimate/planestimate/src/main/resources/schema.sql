--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
	`created_date` date;
	`modified_date` date;
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ;



--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
	`created_date` date;
	`modified_date` date;
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `active` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
  );

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `userrole`;


CREATE TABLE `planestimate.userrole` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
 PRIMARY KEY (`user_id`,`role_id`),
 FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
 FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ;